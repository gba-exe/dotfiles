return {
	{
		"rafamadriz/friendly-snippets",
	},
}
